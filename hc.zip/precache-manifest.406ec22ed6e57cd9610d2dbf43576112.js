self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "9610097d41202c1dd558",
    "url": "/static/js/main.9610097d.chunk.js"
  },
  {
    "revision": "998d5bf9941c99fccd7a",
    "url": "/static/js/1.998d5bf9.chunk.js"
  },
  {
    "revision": "2d525a92b1196a66c44a5d80a79104a3",
    "url": "/index.html"
  }
];